/*
 * File:   main.c
 * Author: guest-7e7aef5d-cdf0-412e-ad99-c7878c8c8fde@transim.com
 *
 * Created on 12/4/2020 7:54:48 AM UTC
 * "Created in MPLAB Xpress"
 */
#define F_CPU 8000000UL //imposto la frequenza per i '_delay_ms' a 8 MHz
#include <util/delay.h>

#include <avr/io.h>
#include <stdint.h>
#include <xc.h>

#include "Frequency.h"

/* MAIN */
int main() {
    CCP = 0xD8;         //abilito la modifica dei registri
    CLKPSR = 0b0000;    //imposto il 'prescaler' a 1 : frequenza 8MHz
    
    /* SETUP */
    /* Definisco i pin a cui sono collegati i led come 'Output' 
    pinMode('PB0', OUTPUT);
    pinMode('PB1', OUTPUT);
    Pagina 76 del Datasheet 
    */
    DDRB = 0b0011;
    /* FINE SETUP */
    
    /* LOOP */
    while(1) {
        /* CORPO DEL LOOP */
        PORTB = 0b0001;     //accendo la lanterna 1:                                            digitalWrite(PB0, HIGH);
        _delay_ms(T_ON);    // tempo in cui la lanterna ? accesa:                               delay(T_ON);
        PORTB = 0b0000;     //spengo la lanterna 1:                                             digitalWrite(PB0, LOW);
        
        _delay_ms(ASYNC_DELAY);  // aspetto il ASYNC_DELAY per accendere l'altra lanterna:      delay(ASYNC_DELAY)
        
        PORTB = 0b0010;     //accendo la lanterna 2:                                            digitalWrite(PB1, HIGH);
        _delay_ms(T_ON);    // tempo in cui la lanterna ? accesa:                               delay(T_ON);
        PORTB = 0b0000;     //spengo la lanterna 2:                                             digitalWrite(PB1, LOW);
        
        /* Termino il ciclo della lanterna 1 e ricomincio:
        la lanterna 1 e' gia' stata spenta per il tempo di "ASYNC_DELAY' e per il tempo di accensione della lanterna 2
        devo determinare quando tempo, del suo ciclo, la lanterna deve ancora stare spenta  */
        _delay_ms( T_OFF - ( ASYNC_DELAY + T_ON ) );    // [ tempo totale in cui la lanterna ? spenta - ( ritardo fra l'accensione della prima e della seconda + tempo lanterna 2 accesa) ]
    }
    /* FINE LOOP */
    
    return 0;
}