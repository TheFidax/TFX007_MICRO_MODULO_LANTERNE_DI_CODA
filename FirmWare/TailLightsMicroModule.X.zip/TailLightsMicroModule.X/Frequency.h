/* 
 * File:   Frequency.h
 * Author: lfidanza997@gmail.com
 *
 * Created on 4/7/2021 5:00:26 PM UTC
 * "Created in MPLAB Xpress"
 *
 *
 *  33  x   1/50 spento = 0,66S = 660mS
 *  1   x   1/50 accesa = 0,02S = 20mS
 *
 *  1000mS = 1S
 *
 */

#ifndef FREQUENCY_H
#define	FREQUENCY_H

//i  seguenti valori identificano il Timing della singola lanterna:
#define T_OFF       660     //(ms) = tempo in cui la lanterna e' 'SPENTA'
#define T_ON        20      //(ms) = tempo in cui la lanterna e' 'ACCESA'

#define ASYNC_DELAY 160

#endif	/* FREQUENCY_H */
